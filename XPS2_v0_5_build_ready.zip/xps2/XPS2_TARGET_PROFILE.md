# XPS2 — perfil alvo

Alvo principal: X Plus Pro
- Android 11
- Amlogic S905X4
- Mali-G31
- 4 GB RAM
- Android userspace 32-bit (`armv8l`)
- ABI do APK: `armeabi-v7a`

Prioridades:
1. estabilidade;
2. resolução nativa/1x como padrão;
3. Vulkan quando disponível;
4. fallback OpenGL ES;
5. controle físico como entrada principal.

A BIOS HLE do Play! é mantida; nenhuma BIOS proprietária da Sony é incluída.

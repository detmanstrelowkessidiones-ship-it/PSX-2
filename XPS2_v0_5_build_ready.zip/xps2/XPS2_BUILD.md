# XPS2 — build Android ARMv7

This source tree is a customized Play! Android build targeted at the X Plus Pro environment.

## Target
- ABI: `armeabi-v7a`
- Android: 11-class environment
- NDK: `25.2.9519653`
- SDK compile/target: 35
- Application ID: `br.com.xps2`
- App name: `XPS2`

## Build prerequisites
Install Android Studio with Android SDK, NDK `25.2.9519653`, CMake `3.31.1`, and a JDK supported by the project.

Create `build_android/local.properties` with your SDK path, for example on Linux:

```
sdk.dir=/home/USER/Android/Sdk
```

Then run from `build_android`:

```
./gradlew assembleRelease
```

The APK should be generated under `build_android/app/build/outputs/apk/release/`.

## BIOS
Play! uses its built-in HLE BIOS; an original Sony PS2 BIOS is not included or required.

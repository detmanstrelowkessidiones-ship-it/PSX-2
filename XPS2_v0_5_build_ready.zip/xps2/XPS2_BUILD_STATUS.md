# XPS2 — integração de fontes v0.2

Esta árvore reúne o código-fonte do Play! enviado pelo usuário e os submódulos
Dependencies/ghc_filesystem, zlib, xxHash e zstd enviados posteriormente.

Alvo do XPS2:
- Android 11
- ABI armeabi-v7a (Android 32-bit)
- Amlogic S905X4 / Mali-G31
- Android TV / controle
- perfil inicial de desempenho

Estado:
- fontes principais presentes
- dependências adicionadas nas posições esperadas
- núcleo Play! presente
- ainda NÃO há APK final neste pacote

Próxima etapa: preparar/validar a build Android com SDK/NDK compatíveis e integrar
a identidade/interface XPS2 sem distribuir BIOS proprietária.
